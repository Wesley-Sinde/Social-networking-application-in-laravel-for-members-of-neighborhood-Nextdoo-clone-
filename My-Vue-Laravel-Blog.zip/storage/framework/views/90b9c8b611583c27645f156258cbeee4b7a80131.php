

<script type="javascript"
src="https://cdn.tiny.cloud/1/kidbho6ws2x58esyf7xh63cykfz1g1omfb9ke1ndospglezj/tinymce/6/tinymce.min.js"
referrerpolicy="origin"></script>

<?php /**PATH C:\xampp\htdocs\Laravel\My-Vue-Laravel-Blog\resources\views/components/head/tinymce-config.blade.php ENDPATH**/ ?>