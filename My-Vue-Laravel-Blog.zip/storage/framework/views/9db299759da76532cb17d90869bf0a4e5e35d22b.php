 <!-- resources/views/chat.blade.php -->
 
 <?php $__env->startSection('content'); ?>
     <div class="flex">

         <?php echo $__env->make('layouts.asidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <section class="bg-white dark:bg-gray-900">

             <div class="flex flex-col flex-1 m-4 overflow-hidden text-gray-800 dark:text-gray-200">
                 <div class="container">
                     <div class="card">
                         <div class="max-w-full px-5 py-4 bg-gray-200 rounded-lg shadow dark:bg-gray-800">
                             <div class="card-header">Chats</div>
                             <div class="card-body">
                                 <chat-messages :messages="messages"></chat-messages>
                             </div>
                             <div class="card-footer">
                                 <chat-form v-on:messagesent="addMessage" :user="<?php echo e(Auth::user()); ?>"></chat-form>
                             </div>
                         </div>
                     </div>
                 </div>

             </div>
         </section>
     <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\My-Vue-Laravel-Blog\resources\views/rooms/chat.blade.php ENDPATH**/ ?>