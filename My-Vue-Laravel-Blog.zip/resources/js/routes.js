import CreatePost from './components/CreatePost.vue';

export const routes = [{
        name: 'create',
        path: '/create',
        component: CreatePost
    },
];